# project-B00139870
project-B00139870 created by GitHub Classroom
// project started on 26/11/2023 
// selected database is on blood donations web-based application which records donors' first name, surname, dob, age, blood group and contact number etc more info will added later.
//Donors HTML form done just following Eoin's theory of baby steps. 
// donors database executing okay 
// data inserted okay from HTML form to database 7 commits so far.
//multiple tables created 
// outputting the data working okay 
//login part done too

